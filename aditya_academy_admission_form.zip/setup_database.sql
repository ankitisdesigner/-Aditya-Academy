
CREATE DATABASE IF NOT EXISTS aditya_academy;
USE aditya_academy;

CREATE TABLE IF NOT EXISTS admissions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_name VARCHAR(100),
  student_aadhar VARCHAR(20),
  category VARCHAR(50),
  dob DATE,
  gender VARCHAR(10),
  father_name VARCHAR(100),
  mother_name VARCHAR(100),
  admitted_class VARCHAR(50),
  admission_date DATE,
  payment INT
);
