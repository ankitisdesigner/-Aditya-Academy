
<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "aditya_academy";

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$student_name = $_POST['student_name'];
$student_aadhar = $_POST['student_aadhar'];
$category = $_POST['category'];
$dob = $_POST['dob'];
$gender = $_POST['gender'];
$father_name = $_POST['father_name'];
$mother_name = $_POST['mother_name'];
$admitted_class = $_POST['admitted_class'];
$admission_date = $_POST['admission_date'];
$payment = $_POST['payment'];

$sql = "INSERT INTO admissions (student_name, student_aadhar, category, dob, gender, father_name, mother_name, admitted_class, admission_date, payment)
VALUES ('$student_name', '$student_aadhar', '$category', '$dob', '$gender', '$father_name', '$mother_name', '$admitted_class', '$admission_date', '$payment')";

if ($conn->query($sql) === TRUE) {
  echo "Admission form submitted successfully.";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
